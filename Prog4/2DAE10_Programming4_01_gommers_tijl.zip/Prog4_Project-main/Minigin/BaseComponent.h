#pragma once
#include <memory>
#include <string>
#include "Transform.h"


namespace TG
{
	
	class BaseComponent
	{
	public:
		virtual void Update(float dt) = 0;
		virtual void Render(const glm::vec3& pos)const = 0;

		BaseComponent()                                = default;
		virtual ~BaseComponent()                       = default;
		BaseComponent& operator=(const BaseComponent&) = delete;
		BaseComponent& operator=(BaseComponent&&)      = delete;
		BaseComponent(const BaseComponent&)            = delete;
		BaseComponent(BaseComponent&&)                 = delete;

	private:

	};
}