#include <string>
#include "GameObject.h"
#include "ResourceManager.h"
#include "Renderer.h"

#include "BaseComponent.h"
#include "RenderComponent.h"

dae::GameObject::~GameObject() = default;

void dae::GameObject::Update(float dt)
{
	for (std::shared_ptr<TG::BaseComponent>const& comp : m_vComponents)
	{
		comp->Update(dt);
	}
}

void dae::GameObject::Render() const
{
	const auto& pos = m_transform.GetPosition();

	for (std::shared_ptr<TG::BaseComponent>const& comp: m_vComponents)
	{
		comp->Render(pos);
	}
	
}

//void dae::GameObject::SetTexture(const std::string& filename)
//{
//	m_texture = ResourceManager::GetInstance().LoadTexture(filename);
//}

void dae::GameObject::SetPosition(float x, float y)
{
	m_transform.SetPosition(x, y, 0.0f);
}

