#include "RenderComponent.h"
#include "Texture2D.h"
#include "ResourceManager.h"
#include "Renderer.h"
#include <glm/glm.hpp>



TG::RenderComponent::RenderComponent(const std::string& path)
{
	SetTexture(path);
}

void TG::RenderComponent::Render(const glm::vec3& pos) const
{
	dae::Renderer::GetInstance().RenderTexture(*m_TextureSPTR, pos.x, pos.y);
}

void TG::RenderComponent::SetTexture(const std::string& filename)
{
	m_TextureSPTR = dae::ResourceManager::GetInstance().LoadTexture(filename);
}
