#pragma once
#include <memory>
#include <vector>
#include "Transform.h"

namespace TG
{
	class BaseComponent;
	class RenderComponent;
}
namespace dae
{
	class Texture2D;

	class GameObject final
	{
	public:
		//----------------------------------------
		//VIRTUAL FUNCTIONS
		virtual void Update(float dt);
		virtual void Render() const;

		//----------------------------------------
		//TRANSFORM FUNCTIONS
		void SetLocalPosition(float x, float y);
		void SetLocalPosition(const glm::vec3& pos);
		void SetWorldPosition(float x, float y);
		void SetWorldPosition(const glm::vec3& pos);
		glm::vec3 GetLocalPosition()const { return m_LocalTransform.GetPosition(); };
		glm::vec3 GetWorldPosition();

		//----------------------------------------
		//COMPONENT FUNCTIONS
		template <typename T, typename... Args>
		void AddComponent(Args&&... args)
		{
			m_vComponents.emplace_back(std::make_shared<T>(std::forward<Args>(args)...));
		}
		template <typename T>
		void RemoveComponent()
		{
			static_assert(std::is_base_of<TG::BaseComponent, T>::value, "T must be a subclass of BaseComponent");
			auto it = std::remove_if(m_vComponents.begin(), m_vComponents.end(), [](std::shared_ptr<TG::BaseComponent> pComponent)
				{
					return dynamic_cast<T*>(pComponent.get()) != nullptr;
				});
			m_vComponents.erase(it, m_vComponents.end());
			if (it == m_vComponents.end())
				throw;
		}
		template<typename T>
		T* GetComponent() const
		{
			static_assert(std::is_base_of<TG::BaseComponent, T>::value, "T must be a subclass of BaseComponent");
			auto it = std::find_if(m_vComponents.begin(), m_vComponents.end(), [](std::shared_ptr<TG::BaseComponent> pComponent)
				{
					return dynamic_cast<T*>(pComponent.get()) != nullptr;
				});

			assert(it != m_vComponents.end() && "Component to get not found");

			return static_cast<T*>((*it).get());
		}		
		template <typename T>
		bool CheckComponent()const
		{
			auto it = std::find_if(m_vComponents.begin(), m_vComponents.end(), [](std::shared_ptr<TG::BaseComponent> component)
				{return dynamic_cast<T*>(component.get()) != nullptr; });
			return (it != m_vComponents.end());

		};

		//----------------------------------------
		//HIERARCHICAL FUNCTIONS
		void SetParent(GameObject* parent, bool keepWorldPosition);
		GameObject* GetParent() { return m_parent; };
		GameObject* GetChildAtIndex(size_t index) { return m_vChilds[index]; };
		size_t GetNumOfChilds() { return m_vChilds.size(); };
		void SetPositionDirty() { m_IsPositionDirty = true; };
		bool IsChild(const GameObject* otherObj)const;

		//----------------------------------------
		//RULE OFF 5 FUNCTIONS
		GameObject()                                   = default;
		virtual ~GameObject()                          = default;
		GameObject(const GameObject& other)            = delete;
		GameObject(GameObject&& other)                 = delete;
		GameObject& operator=(const GameObject& other) = delete;
		GameObject& operator=(GameObject&& other)      = delete;

	private:
		Transform m_LocalTransform{};
		Transform m_WorldTransform{};
		std::vector<std::shared_ptr<TG::BaseComponent>> m_vComponents{};
		std::vector<GameObject*> m_vChilds{};
		GameObject* m_parent{};
		bool m_IsPositionDirty{ false };
		void UpdateWorldPosition();

		void AddChild(GameObject* child);
		void RemoveChild(GameObject* child);
	};
}
