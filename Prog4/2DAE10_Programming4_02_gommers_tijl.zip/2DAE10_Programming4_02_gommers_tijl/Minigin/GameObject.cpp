#include <string>
#include "GameObject.h"
#include "ResourceManager.h"
#include "Renderer.h"
#include <algorithm>

#include "BaseComponent.h"
#include "RenderComponent.h"

void dae::GameObject::SetParent(GameObject* parent, bool keepWorldPosition)
{
	if (IsChild(parent) || parent == this || m_parent == parent)
		return;
	if (parent == nullptr)
		SetLocalPosition(GetWorldPosition());
	else
	{
		if (keepWorldPosition)
			SetLocalPosition(GetWorldPosition() - parent->GetWorldPosition());
		SetPositionDirty();
	}

	if (m_parent) 
		m_parent->RemoveChild(this);

	m_parent = parent;

	if (m_parent) 
		m_parent->AddChild(this);

}

bool dae::GameObject::IsChild(const GameObject* otherObj)const
{
	return std::ranges::any_of(m_vChilds, [otherObj](GameObject* e) {return e == otherObj; });
}

void dae::GameObject::UpdateWorldPosition()
{
	if (m_IsPositionDirty)
	{
		if (m_parent == nullptr)
			m_WorldTransform = m_LocalTransform;
		else
			SetWorldPosition(m_parent->GetWorldPosition() + GetLocalPosition()) ;
	}
	m_IsPositionDirty = false;
}

void dae::GameObject::AddChild(GameObject* child)
{
	m_vChilds.push_back(child);
}

void dae::GameObject::RemoveChild(GameObject* child)
{
	m_vChilds.erase(std::remove_if(m_vChilds.begin(), m_vChilds.end(), [child](GameObject* e) {return child == e; }));
}

void dae::GameObject::Update(float dt)
{
	for (std::shared_ptr<TG::BaseComponent>const& comp : m_vComponents)
	{
		comp->Update(dt);
	}
}

void dae::GameObject::Render() const
{

	for (std::shared_ptr<TG::BaseComponent>const& comp: m_vComponents)
	{
		
		comp->Render();
	}
}

void dae::GameObject::SetLocalPosition(float x, float y)
{
	m_LocalTransform.SetPosition(x, y, 0.0f);
	SetPositionDirty();
}

void dae::GameObject::SetLocalPosition(const glm::vec3& pos)
{
	SetLocalPosition(pos.x, pos.y);
}

void dae::GameObject::SetWorldPosition(float x, float y)
{
	m_WorldTransform.SetPosition(x, y, 0.f);
}

void dae::GameObject::SetWorldPosition(const glm::vec3& pos)
{
	SetWorldPosition(pos.x, pos.y);
}

glm::vec3 dae::GameObject::GetWorldPosition()
{
	if (m_IsPositionDirty)
		UpdateWorldPosition();
	return m_WorldTransform.GetPosition();
}



